from .solver import LaplaceSolver2D

__all__ = ["LaplaceSolver2D"]
