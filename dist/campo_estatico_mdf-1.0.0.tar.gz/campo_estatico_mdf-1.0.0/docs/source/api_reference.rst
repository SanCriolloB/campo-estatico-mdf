Referencia de la API
====================

.. automodule:: campo_estatico_mdf.solver
   :members:
   :undoc-members:
   :show-inheritance:
