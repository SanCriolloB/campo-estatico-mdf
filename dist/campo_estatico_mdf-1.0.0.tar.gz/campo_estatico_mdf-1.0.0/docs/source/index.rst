.. campo-estatico-mdf documentation master file, created by
   sphinx-quickstart on Wed Nov 12 13:50:43 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.

.. campo-estatico-mdf documentation master file

Bienvenido a la documentación de campo-estatico-mdf
====================================================

.. toctree::
   :maxdepth: 2
   :caption: Contenido

   teoria
   api_reference
   tutorial

